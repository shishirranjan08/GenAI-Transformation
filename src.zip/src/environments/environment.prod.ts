export const environment = {
  production: true,
  // base_url: "https://xena-backend-genai.azurewebsites.net/",
  base_url: "https://uhg-backend.azurewebsites.net/",
  firebaseConfig: {
    apiKey: "AIzaSyCIzQ1cchFL-PCQ59ZWuQYKLcQ0oDMy49Y",
    authDomain: "xenaai.firebaseapp.com",
    projectId: "xenaai",
    storageBucket: "xenaai.appspot.com",
    messagingSenderId: "773071112270",
    appId: "1:773071112270:web:1919a90b8adc981e921b1f",
    measurementId: "G-DWZFQXHCLD",
  },
};
