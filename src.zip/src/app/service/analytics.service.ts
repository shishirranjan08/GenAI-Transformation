import { Injectable } from "@angular/core";
import { AngularFireAnalytics } from "@angular/fire/compat/analytics";

@Injectable({
  providedIn: "root",
})
export class AnalyticsService {
  constructor(private analytics: AngularFireAnalytics) {}

  // to log app level events
  logEvent = (eventname: string, component: string) => {
    this.analytics.logEvent(eventname, { component: component });
  };

  // to log errors
  logErrorEvent = (eventname: string, component: string, error: string) => {
    this.analytics.logEvent(eventname, { component: component, error: error });
  };

  // log user driven event based on app logic
  logCustomEvent = (eventname: string, component?: string) => {
    if (component) {
      this.analytics.logEvent(eventname, { component: component });
    } else {
      this.analytics.logEvent(eventname);
    }
  };

  setUserId = (userId: string) => {
    this.analytics.setUserId(userId);
  };

}
