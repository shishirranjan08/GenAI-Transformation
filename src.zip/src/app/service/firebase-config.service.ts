import { Injectable } from '@angular/core';
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FirebaseConfigService {

  app = initializeApp(environment.firebaseConfig);
  db = getFirestore(this.app);

  constructor() { }


  getDBReference(){
    return this.db;
  }


}
