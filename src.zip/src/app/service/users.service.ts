import { Injectable } from "@angular/core";
import {
  AngularFireDatabase,
  AngularFireList,
  AngularFireObject,
} from "@angular/fire/compat/database";
import {
  AngularFirestore,
  AngularFirestoreCollection,
} from "@angular/fire/compat/firestore";
import { User } from "../interfaces/user";

import {
  arrayUnion,
  collection,
  doc,
  documentId,
  getDoc,
  getDocs,
  getFirestore,
  or,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
} from "firebase/firestore";
import { initializeApp } from "firebase/app";
import { FirebaseConfigService } from "./firebase-config.service";

@Injectable({
  providedIn: "root",
})
export class UsersService {
  constructor(private config: FirebaseConfigService) {}

  getUserData = async (collectionName: string = "users-stage", userId: string) => {
    let d: any = {};
    const q = query(
      collection(this.config.getDBReference(), collectionName),
      or(where("email", "==", userId), where("adid", "==", userId))
    );
    const querySnapshot = await getDocs(q);
    querySnapshot.forEach((doc) => {
      if (doc) d = { id: doc.id, data: doc.data() as User };
    });
    return d;
  };

  getUserDataFromId = async (id: string): Promise<any> => {
    const db = this.config.getDBReference();
    const snap = await getDoc(doc(db, "users-stage", id));
    if (snap.exists()) {
      return snap.data();
    } else {
      console.log("no such doc");
    }
  };

  pushPromptsForUser = async (id: string, prompt: string,response:string): Promise<any> => {
    const db = this.config.getDBReference();
    const userRef = doc(db, "users-stage", id);
    let promptObj = {
      text: prompt,
      response:response,
      timestamp: new Date(), // this should give the date back but with conversion
    };
    await updateDoc(userRef, {
      prompts: arrayUnion(promptObj),
    });
  };
}
