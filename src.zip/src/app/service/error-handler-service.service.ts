import { ErrorHandler, Injectable, NgZone } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AlertComponent } from '../alert/alert.component';

@Injectable({
  providedIn: 'root'
})
export class ErrorHandlerService extends ErrorHandler {

  constructor(private dialog: MatDialog, private ngZone: NgZone) { 
    super();
  }

  override handleError(err: any): void {
    console.error(err);
    this.ngZone.run(() => {
      this.dialog.open(AlertComponent, {
        data: { message: err.message, buttonText: 'Ok' },
      });
    });
  }
}
