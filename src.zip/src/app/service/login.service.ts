import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs/internal/BehaviorSubject";

@Injectable({
  providedIn: "root",
})
export class LoginService {
  private loginSuccess = new BehaviorSubject(false);
  public loginApiResponse = this.loginSuccess.asObservable();

  private logoutSuccess = new BehaviorSubject(true);
  public logoutApiResponse = this.logoutSuccess.asObservable();

  private userDataSource = new BehaviorSubject({
    name: "",
    email: "",
    passcode: "",
  });
  currentUserData = this.userDataSource.asObservable();

  constructor() {}

  updateLoginStatus(value: any) {
    this.loginSuccess.next(value);
  }

  updateLoginData(data: { name: any; email: any; passcode: any }) {
    this.userDataSource.next(data);
  }

  // updateLogoutStatus(value: any){
  //   this.logoutSuccess.next(value);
  // }

  // checkUserEmail(email: string){
  //   console.log(this.userData.filter(data => data.email === email));
  //   return this.userData.filter(data => data.email === email).length;
  // }

  // checkUserPasscode(passcode: string){
  //   return this.userData.filter(data => data.passcode === passcode).length;
  // }
}
