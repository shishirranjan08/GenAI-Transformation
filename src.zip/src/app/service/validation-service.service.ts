import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ValidationService {

  constructor() { }

  isEmailValid(email: string) {    
    // var regexMail = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    // if(regexMail.test(email) && email.indexOf("@wipro.com", email.length - "@wipro.com".length) !== -1){        
    //   return true;
    // }
    // else{
    //   return false;
    // }
    return true;
  }

  isPasscodeValid(passcode: string){
    var regexPasscode = /^[0-9]{1,6}$/;
    if(regexPasscode.test(passcode)){
      return true;
    } else
    {
      return false;
    }
  
  }
}
