import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent implements OnInit {

  message: string = '';
  buttonText = 'Ok';
  buttonText2 = 'Ok';

  constructor(
    @Inject(MAT_DIALOG_DATA)
    private data: {
      message: string;
      icon: string;
      buttonText: string;
      buttonText2:string;
    },private dialogRef: MatDialogRef<AlertComponent>
  ) { 
    if (data?.message) this.message = data.message;
    if (data?.buttonText) this.buttonText = data.buttonText;
    if (data?.buttonText2) this.buttonText2 = data.buttonText2;
  }

  ngOnInit(): void {
  }

  closeDialog() {
    this.dialogRef.close();
  }

  confirm() {
    // closing itself and sending data to parent component
    this.dialogRef.close({ data: 'yes' })
  }

}
