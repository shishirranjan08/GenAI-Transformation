import {
  Component,
  ElementRef,
  Renderer2,
  ViewChild,
  ChangeDetectorRef,
  OnInit,
} from "@angular/core";
import { HttpClient, HttpEventType, HttpHeaders } from "@angular/common/http";
import { environment } from "src/environments/environment";
import { LoginService } from "../service/login.service";
import { BreakpointObserver, BreakpointState } from "@angular/cdk/layout";
import { v4 as uuidv4 } from "uuid";
import { DatePipe } from "@angular/common";
import { AnalyticsService } from "../service/analytics.service";
import { UsersService } from "../service/users.service";
import { ActivatedRoute, Router } from "@angular/router";
import { User } from "../interfaces/user";
import { UserIdleService } from "angular-user-idle";
import { concatMap, delay, filter, map, of, tap } from "rxjs";
import { MatDialog } from "@angular/material/dialog";
import { AlertComponent } from "../alert/alert.component";

@Component({
  selector: "app-chat",
  templateUrl: "./chat.component.html",
  styleUrls: ["./chat.component.css"],
})
export class ChatComponent implements OnInit {
  title = "ui-chatbot";
  showPlaceholder = false;
  messages = [
    {
      user: "bot",
      message: "",
      link: "",
      name: "",
      id: 0,
      feedback: "false",
      dislike: "false",
    },
  ];
  userMessage: any = "";
  historyMessage: string = "";
  focusAdded = false;
  @ViewChild("typedMessage") typedMessage!: ElementRef;
  @ViewChild("sidebarContainer") sidebarContainer!: ElementRef;
  @ViewChild("backdropContainer") backdropContainer!: ElementRef;
  @ViewChild("messageinput") messageinput!: ElementRef;
  //@ViewChild("scrollMe", { read: ElementRef })
  //public scrollMe!: ElementRef<any>;

  showChatBotUi = true;
  showSideBar = false;
  userPrompts: any = [];
  loader = false;

  smallScreen = false;
  timerStart = false;
  requestId = "";
  chatHistory = [{}];
  chatObject = {};
  userData: any;
  userId = "";
  userName = "";
  timeout: number = 240;
  avatarName: string = "";
  Object = Object;
  typedChunk = 0;
  chunksize = 0;
  chunkCompleted = false;
  completedChar = 0;
  textToType = "";

  componentName = "ChatComponent";

  ERROR_BOT_RESPONSE = "BOT_RESPONSE_ERROR";
  LOG_THUMBS_UP = "LOG_THUMBS_UP";
  LOG_THUMBS_DOWN = "LOG_THUMBS_DOWN";

  constructor(
    private httpClient: HttpClient,
    private cdr: ChangeDetectorRef,
    private renderer: Renderer2,
    private loginService: LoginService,
    private breakpointObserver: BreakpointObserver,
    public datepipe: DatePipe,
    public dialog: MatDialog,
    private analytics: AnalyticsService,
    private userService: UsersService,
    private route: ActivatedRoute,
    private router: Router,
    private userIdle: UserIdleService
  ) {
    // detect screen size changes
    this.breakpointObserver
      .observe(["(max-width: 600px)"])
      .subscribe((result: BreakpointState) => {
        if (result.matches) {
          this.smallScreen = false;
        } else {
          this.smallScreen = true;
        }
      });
  }

  ngOnInit(): void {
    //Start watching for user inactivity.
    this.userIdle.startWatching();

    // Start watch when time is up.
    this.userIdle.onTimeout().subscribe(() => {
      this.userIdle.stopTimer();
      this.userIdle.stopWatching();
      this.messages.push({
        user: "bot",
        message: "Hey!! We are waiting for you to comeback!",
        link: "",
        name: "",
        id: this.messages.length, // todo : must be uuid
        feedback: "false",
        dislike: "false",
      });
    });

    this.userIdle.onTimerStart().subscribe((count) => {
      if (this.timerStart === false && count > 0) {
        this.messages.push({
          user: "bot",
          message: "Hey!! Are you there?",
          link: "",
          name: "",
          id: this.messages.length, // todo : must be uuid
          feedback: "false",
          dislike: "false",
        });
        this.timerStart = true;
      }
    });

    this.analytics.logEvent("app_open", this.componentName); // todo: get the component name dynamically

    this.route.params.subscribe((params: any) => {
      this.userId = params.id;
    });
    this.loginService.currentUserData.subscribe((userData) => {
      this.userData = userData;
      this.getUserName();
      this.messages[0].message =
        "Hello " +
        this.userName +
        "! Hope you are having a good day. I am Xena, UHG virtual assistant. I can help with benefits coverage, provider services and pricing. How can I help you today?"
        //"! My name is Xena and I am here to help! Please ask me any questions about business agendas, special events, support contacts, and more";
    });
    this.loginService.loginApiResponse.subscribe((data) => {
      this.showChatBotUi = data;
      this.chatHistory.length = 0;
      this.requestId = uuidv4();
    });
    this.getUserDetails();
  }

  getUserDetails = async () => {
    let userData: User = await this.userService.getUserDataFromId(this.userId);
    this.userData = userData;
    this.getUserName();
    this.messages[0].message =
      "Hello " +
      this.userName +
      "! Hope you are having a good day. I am Xena, UHG virtual assistant. I can help with benefits coverage, provider services and pricing. How can I help you today?"
      //"! My name is Xena and I am here to help! Please ask me any questions about business agendas, special events, support contacts, and more";
  };

  getUserQueries = async (userId: string) => {
    let userData: User = await this.userService.getUserDataFromId(userId);
    this.userPrompts = userData.prompts ? userData.prompts : [];
    if (this.userPrompts) {
      this.userPrompts = this.userPrompts
        ? this.userPrompts.reverse()
        : this.userPrompts;
      this.converDateForPromts();
    }
  };

  sendMessage() {
    this.userIdle.stopTimer();
    this.timerStart = false;
    this.focusAdded = false;
    this.userMessage =
      this.historyMessage.length > 0
        ? this.historyMessage
        : this.typedMessage.nativeElement.textContent;
    if (this.userMessage.length > 0) {
      this.messages.push({
        user: "user",
        message: this.userMessage,
        link: "",
        name: "",
        id: this.messages.length, // todo : must be uuid
        feedback: "false",
        dislike: "false",
      });
      this.loader = true;
      this.chatObject = {
        role: "user",
        content: this.userMessage,
        timestamp: this.datepipe.transform(new Date(), "MM/dd/yyyy h:mm:ss a"),
      };
      if (this.chatHistory.length > 2) {
        this.chatHistory.shift();
      }
      this.chatHistory.push(this.chatObject);
      const data = {
        chat_history: this.chatHistory,
        query: this.chatObject,
        request_id: this.requestId,
        language: "en",
        user_info: this.userData.email,
      };
      
      if(this.typedMessage.nativeElement.innerHTML !== ''){
        while (this.typedMessage.nativeElement.hasChildNodes()) {
          this.typedMessage.nativeElement.removeChild(this.typedMessage.nativeElement.firstChild);
        }
        console.log(this.typedMessage.nativeElement.innerHTML,this.typedMessage.nativeElement.textContent);
      }

      this.typedMessage.nativeElement.style.lineHeight = "55px";
      this.completedChar = 0;
      this.textToType = "";
      this.typedChunk = 0;
      this.getBotsReplyStream(data);
    }
  }

  urlify(text: string) {
    var urlRegex =
      /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/gm;
    return text.replace(urlRegex, function (url) {
      return '<a href="' + url + '">' + url + "</a>";
    });
    // or alternatively
    // return text.replace(urlRegex, '<a href="$1">$1</a>')
  }

  getUserName() {
    this.userName = this.userData.name;
    this.getAvatar();
  }

  getAvatar() {
    this.httpClient
      .get("../../assets/avatar/" + this.userName + ".png", {
        responseType: "blob",
      })
      .subscribe(
        (resp) => {
          console.log("got Avatar");
          if (resp.type !== "text/html") {
            this.avatarName = this.userName;
          } else if (this.userData.email === "tony.bhattacharjee@wipro.com") {
            this.avatarName = "UserM";
          } else {
            if (this.userData.gender === "F") {
              this.avatarName = "UserF";
            } else if (this.userData.gender === "M") {
              this.avatarName = "UserM";
            } else {
              this.avatarName = "User";
            }
          }
        },
        (err: any) => {
          if (err.status !== 200) {
            if (this.userData.gender === "F") {
              this.avatarName = "UserF";
            } else if (this.userData.gender === "M") {
              this.avatarName = "UserM";
            } else {
              this.avatarName = "User";
            }
          } else {
            this.avatarName = this.userName;
          }
          console.log("this.avatarName", this.avatarName);
        }
      );
  }

  camelCase(str: any) {
    const strArr = str.split("");
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  }

  ngAfterViewChecked() {
    //your code to update the model
    this.cdr.detectChanges();
  }

  clickedUp(id: any) {
    this.messages.forEach((message: any) => {
      if (message.id === id) {
        if (message.feedback === "false") {
          message.feedback = "true";
          message.dislike = "false";
        } else if (message.feedback === "true") {
          message.feedback = "false";
        }
      }
    });
    this.messages.push({
      user: "bot",
      message: "Thank you!!",
      link: "",
      name: "",
      id: this.messages.length, // todo : must be uuid
      feedback: "feedback",
      dislike: "",
    });
  }
  clickedDown(id: any) {
    this.messages.forEach((message: any) => {
      if (message.id === id) {
        if (message.dislike === "false") {
          message.dislike = "true";
          message.feedback = "false";
        } else if (message.dislike === "true") {
          message.dislike = "false";
        }
      }
    });
    this.messages.push({
      user: "bot",
      message:
        "I am sorry to know that I could not answer to your satisfaction and will look into it. Meanwhile, can I assist you with something else?",
      link: "",
      name: "",
      id: this.messages.length, // todo : must be uuid
      feedback: "feedback",
      dislike: "",
    });
  }

  closeChatBot() {
    this.showChatBotUi = false;
  }

  getBotsReplyStream(data: any) {
    fetch(environment.base_url + "wega_stream", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
      .then(async (response: any) => {
        console.log("data", data);

        if(response.ok){
        this.userMessage = data.query.content;
        // update firebase with the user prompt
        let result = "";
        this.messages.push({
          user: "bot",
          message: "",
          link: "",
          name: "",
          id: this.messages.length,
          feedback: "false",
          dislike: "false",
        });
        console.log("got resp", response);
        const decoder = new TextDecoder();
        // response.body is a ReadableStream
        const reader = response.body.getReader();
        for await (const chunk of this.readChunks(reader)) {
          result = decoder.decode(chunk, { stream: true });
          this.typeTextToChat(result);
        }
        }else{
          throw new Error(response);
        }

      })
      .catch((error) => {
        console.log("got resp", error);
        //this.messages.pop();
        this.messages.push({
          user: "bot",
          message:
            "Ohh! Looks like we ran into a problem ! Can you please ask again ?",
          link: "",
          name: "",
          id: this.messages.length,
          feedback: "false",
          dislike: "false",
        });
        this.loader = false;
        this.historyMessage = "";

        // TODO: should log the error from api itself
        this.analytics.logErrorEvent(
          "app_error",
          this.componentName,
          this.ERROR_BOT_RESPONSE
        );
      });
  }
  // readChunks() reads from the provided reader and yields the results into an async iterable
  readChunks(reader: any) {
    var _this = this;
    return {
      async *[Symbol.asyncIterator]() {
        let readResult = await reader.read();
        if (readResult.done) {
          _this.chunkCompleted = true;
        }
        while (!readResult.done) {
          console.log(readResult.done);
          yield readResult.value;
          readResult = await reader.read();
        }
      },
    };
  }

  showLogoutModal() {
    const dialogRef = this.dialog.open(AlertComponent, {
      data: {
        message: "Do you want to sign out for sure ?",
        buttonText: "Yes",
        buttonText2: "No",
      },
    });

    dialogRef.afterClosed().subscribe((res) => {
      // received data from dialog-component
      console.log(res.data);
      if (res.data) {
        this.logout();
      }
    });
  }

  typeTextToChat(result: any) {
    this.typedChunk++;
    console.log("this.typedChunk",this.typedChunk);
    const streamArray = result.replaceAll("{", "*{").substring(1).split("*");
    const streamObjectArr = streamArray.map((ele: any, index: any) => {
      try {
        return JSON.parse(ele);
      } catch {
        return "";
      }
    });
    console.log("streamObjectArr", JSON.stringify(streamObjectArr));
    this.textToType =
      this.textToType + streamObjectArr.map((obj: any) => obj.content).join("");
    let id = "messageinput" + (this.messages.length - 1);
    let messageDiv = document.getElementById(id)!;

    streamObjectArr.forEach((str: any, index: number) => {
      if (str["content"]) {
        let strArr = str["content"].split("");
        if (strArr.length >= 1) {
          strArr.forEach((char: any) => {
            of(char)
              .pipe(
                tap((val) => {}),
                concatMap((item) => of(item).pipe(delay(1000)))
              )
              .subscribe(
                (val) => {
                  this.completedChar++;
                  this.typeLetter(val, messageDiv);

                  if (this.textToType.length === this.completedChar) {
                    //this.pushPromptsForUser();
                    // const responseString = this.textToType;
                    // let a = this.userService.pushPromptsForUser(
                    //   this.userId,
                    //   this.userMessage,
                    //   responseString
                    // );
                    // a.then((a) => console.log("done"));
                    // a.catch((e) => console.log(e));
                    setTimeout(() => {
                      this.loader = false;
                      const xenaResponse = {
                        role: "assistant",
                        content: this.textToType,
                        timestamp: this.datepipe.transform(
                          new Date(),
                          "MM/dd/yyyy h:mm:ss a"
                        ),
                      };
                      if (this.chatHistory.length > 2) {
                        this.chatHistory.shift();
                      }
                      this.chatHistory.push(xenaResponse);
                      this.historyMessage = "";
                    }, 500);
                    const responseString = this.textToType;
                    let a = this.userService.pushPromptsForUser(
                      this.userId,
                      this.userMessage,
                      responseString
                    );
                    a.then((a) => console.log("done"));
                    a.catch((e) => console.log(e));
                  }
                },
                (e) => console.log(e),
                () => {
                  if (
                    this.chunksize === this.typedChunk &&
                    this.chunkCompleted === true
                  ) {
                    console.log("final Complete");
                  }
                }
              );
          });
        }
      }
    });
  }

  typeLetter(str: any, messageDiv: any) {
    messageDiv.innerHTML += str;
  }

  getBotsReply(data: any) {
    const headers = new HttpHeaders({
      "Content-Type": "application/json",
    });
    return this.httpClient
      .post(environment.base_url + "wega_en", data, { headers })
      .pipe();
  }

  sendHistoryMessage(message: string) {
    this.historyMessage = message;
    this.sendMessage();
    this.closePrompts();
  }

  goToLink(link: any) {
    window.open(link, "_blank");
  }

  getPolicyName(link: string) {
    var name = "";
    if (link === "" || link === "None") {
      return "";
    } else {
      let nameStr = link.split("?")[1];
      let name = nameStr === undefined ? "Link" : nameStr.split("=")[1];
      return name;
    }
  }

  logout() {
    this.router.navigate(["/login"]);
    this.closeChatBot();
    this.userIdle.stopWatching();
    // this.userService.updateLogoutStatus(true);
    this.loginService.updateLoginStatus(false);
    this.analytics.logCustomEvent("app_sign_out");
  }

  closePrompts() {
    //this.sidebarContainer.nativeElement.classList.add('deactive');
    //this.sidebarContainer.nativeElement.classList.remove('active');
    this.sidebarContainer.nativeElement.classList.add("slide-out");
    this.sidebarContainer.nativeElement.classList.remove("slide-in");
    //this.backdropContainer.nativeElement.classList.add('slide-out');
    //this.backdropContainer.nativeElement.classList.remove('slide-in');
    setTimeout(() => {
      this.showSideBar = false;
    }, 200);
  }

  showPrompts() {
    //this.sidebarContainer.nativeElement.classList.add('active');
    //this.sidebarContainer.nativeElement.classList.remove('deactive');
    this.sidebarContainer.nativeElement.classList.add("slide-in");
    this.sidebarContainer.nativeElement.classList.remove("slide-out");
    //this.backdropContainer.nativeElement.classList.add('slide-in');
    //this.backdropContainer.nativeElement.classList.remove('slide-out');
    setTimeout(() => {
      this.showSideBar = !this.showSideBar;
    }, 200);
    // get user prompts from firebase
    this.getUserQueries(this.userId);
  }

  converDateForPromts() {
    this.userPrompts.map((element: any) => {
      const d = element.timestamp.toDate();
      element.date = d.toDateString().split(" ").slice(1).join(" ");
    });
    this.userPrompts = this.groupBy(this.userPrompts, (c: any) => c.date);
  }

  groupBy(xs: any, f: any) {
    return xs.reduce(
      (r: any, v: any, i: any, a: any, k: any = f(v)) => (
        (r[k] || (r[k] = [])).push(v), r
      ),
      {}
    );
  }

  changeLineHeight(e: any) {
    console.log(this.typedMessage.nativeElement.innerHTML,this.typedMessage.nativeElement.textContent);
    if (this.typedMessage.nativeElement.textContent === "") {
      if(this.typedMessage.nativeElement.innerHTML !== ''){
        while (this.typedMessage.nativeElement.hasChildNodes()) {
          this.typedMessage.nativeElement.removeChild(this.typedMessage.nativeElement.firstChild);
        }
        console.log(this.typedMessage.nativeElement.innerHTML,this.typedMessage.nativeElement.textContent);
      }
      this.typedMessage.nativeElement.style.lineHeight = "55px";
    } else {
      this.typedMessage.nativeElement.style.lineHeight = "22px";
    }
  }

  addFocusInput() {
    this.focusAdded = true;
    this.showPlaceholder = true;
  }
  removeFocusInput(event: any) {
    this.focusAdded = false;
    event.stopPropagation();
  }
}
