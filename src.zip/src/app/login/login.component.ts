import { Component, OnInit } from "@angular/core";
import { LoginService } from "../service/login.service";
import { ValidationService } from "../service/validation-service.service";
import { ActivatedRoute, Router } from "@angular/router";
import { AlertComponent } from "../alert/alert.component";
import { MatDialog } from "@angular/material/dialog";
import { BreakpointObserver, BreakpointState } from "@angular/cdk/layout";
import { UsersService } from "../service/users.service";
import { AnalyticsService } from "../service/analytics.service";
import { User } from "../interfaces/user";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  email: any;
  errorMessage: any;
  showLogin = true;
  userData: any;
  submitted = false;

  showEmailError = false;
  showEmailValidationError = false;
  showPasscodeError = false;
  showPasscodeWrongError = false;
  showEmailRegisterError = false;
  showServerError = false;
  showEmailBlankError = false;

  smallScreen = false;

  isLoggedIn = false;

  componentName = "LoginComponent";

  ERROR_WRONG_PASS_KEY = "WRONG_PASSKEY";

  constructor(
    private userService: LoginService,
    private validationService: ValidationService,
    private router: Router,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private breakpointObserver: BreakpointObserver,
    private userFBService: UsersService,
    private analytics: AnalyticsService
  ) {
    // detect screen size changes
    this.breakpointObserver
      .observe(["(max-width: 600px)"])
      .subscribe((result: BreakpointState) => {
        if (result.matches) {
          this.smallScreen = false;
        } else {
          this.smallScreen = true;
        }
      });
  }

  ngOnInit(): void {
    this.analytics.logEvent("app_open", this.componentName); // todo: get the component name dynamically
    this.userService.currentUserData.subscribe((userData) => {
      this.userData = userData;
      console.log(this.userData, "this.userData");
      console.log(this.userData.prompts, "this.userData");
    });
    this.userService.loginApiResponse.subscribe(
      (loginStatus) => {this.isLoggedIn = loginStatus;this.userData = loginStatus ? this.userData :[]}
    );
  }

  login(data: any) {
    if (this.userData.email.toString().trim() == 0) {
      this.showEmailValidationError = true;
      this.showEmailError = false;
      this.showEmailBlankError = false;
    } else if (this.validationService.isEmailValid(this.userData.email)) {
      // this.showEmailValidationError = false;
      // this.showEmailError = false;
      if (this.validationService.isPasscodeValid(this.userData.passcode)) {
        this.showPasscodeError = false;
        this.userValidation();
      } else {
        this.showPasscodeError = true;
      }
    } else {
      this.showEmailError = true;
      this.showEmailValidationError = false;
    }
  }

  async userValidation() {
    // service to fetch user passkey
    let resp : any = await this.userFBService.getUserData(
      "users-stage",
      this.userData.email ? this.userData.email.toString().toLowerCase() : ""
    );
    if(Object.keys(resp).length === 0){
      this.showEmailRegisterError = true;
      this.showEmailBlankError = false;
    }
    if (resp.data.passkey == this.userData.passcode) {
      // passcode matches
      // this.showLogin = false;
      this.showPasscodeWrongError = false;
      this.userService.updateLoginStatus(true);

      this.router.navigate(['/chat', resp.id]);
      this.userService.updateLoginData({ name: resp.data.name, email: resp.data.email, passcode: resp.data.passkey });
      this.analytics.setUserId(this.userData.email.toString().toLowerCase());
    } else {
      //  if passkey doesn't match
      this.analytics.logErrorEvent(
        "app_error",
        this.componentName,
        this.ERROR_WRONG_PASS_KEY
      );
      this.showPasscodeWrongError = true;
    }
  }

  numericEntry(event: { which: any; keyCode: any }): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  openAlertDialog(alertMessage: any) {
    this.dialog.open(AlertComponent, {
      data: {
        message: alertMessage,
      },
    });
  }

  validateEmailId() {
    this.validateBlankEmailId();
  }

  validateBlankEmailId() {
    //blank
    if (this.userData.email === undefined || this.userData.email.length == 0) {
      this.showEmailBlankError = true;
      this.showEmailError = false;
      this.showEmailRegisterError = false;
    } else {
      this.showEmailBlankError = false;
      this.validateEmailIdFormat();
    }
  }

  validateEmailIdFormat() {
    if (this.validationService.isEmailValid(this.userData.email)) {
      this.showEmailError = false;
      this.validateRegisteredEmailId();
    } else {
      this.showEmailError = true;
      this.showEmailRegisterError = false;
    }
  }

  async validateRegisteredEmailId() {
    // service to fetch user passkey
    let resp : any = await this.userFBService.getUserData(
      "users-stage",
      this.userData.email ? this.userData.email.toString().toLowerCase() : ""
    );
    if(Object.keys(resp).length === 0){
      this.showEmailRegisterError = true;
      this.showEmailError = false;
    } else {
      this.showEmailRegisterError = false;
    }
  }

  validatePassKey() {
    if (this.userData.passcode.length == 0) {
      this.showPasscodeError = true;
      this.showPasscodeWrongError = false;
    } else {
      this.showPasscodeError = false;
    }
  }  
}
