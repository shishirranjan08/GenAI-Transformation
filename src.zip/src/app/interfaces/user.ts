export interface User {
    $key: string;
    name: string;
    email: string
    passkey: Number;
    prompts:any[]
 }

