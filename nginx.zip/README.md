npm i
ng build
npx cap sync