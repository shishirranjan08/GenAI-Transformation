import json

connection_data = [

        {
        "openai.api_type": "azure",  
        "openai.api_base": "https://########.com/",
        "openai.api_version": "2023########ew",
        "openai.api_key": "########",
        "openai.engine_name":"########th",
        "openai.deployment_name":"ao########od-uk-south",
        "openai.deployment_region":"uk########th"
    },
    {
        "openai.api_type": "azure",  
        "openai.api_base": "https://a########ure.com/",
        "openai.api_version": "2023########",
        "openai.api_key": "d########b6",
        "openai.engine_name":"g########-2",
        "openai.deployment_name":"a########-2",
        "openai.deployment_region":"ea########2"
    },
    {
        "openai.api_type": "azure",  
        "openai.api_base": "https://########.azure.com/",
        "openai.api_version": "20########ew",
        "openai.api_key": "8########6",
        "openai.engine_name":"G########4",
        "openai.deployment_name":"g########s",
        "openai.deployment_region":"fr########al"
    }

]

