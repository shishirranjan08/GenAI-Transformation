try {
  var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  var recognition = new SpeechRecognition();
}
catch(e) {
  console.error(e);
  $('.no-browser-support').show();
  $('.app').hide();
}


var noteTextarea = $('#messageText');
//var instructions = $('#recording-instructions');
//var notesList = $('ul#notes');

var noteContent = '';

// Get all notes from previous sessions and display them.
//var notes = getAllNotes();
//renderNotes(notes);



/*-----------------------------
      Voice Recognition 
------------------------------*/

// If false, the recording will stop after a few seconds of silence.
// When true, the silence period is longer (about 15 seconds),
// allowing us to keep recording even when the user pauses. 
recognition.continuous = false;

// This block is called every time the Speech APi captures a line. 
recognition.onresult = function(event) {

  // event is a SpeechRecognitionEvent object.
  // It holds all the lines we have captured so far. 
  // We only need the current one.
  var current = event.resultIndex;

  // Get a transcript of what was said.
  var transcript = event.results[current][0].transcript;

  var myRe = /[A-Za-z]/;
 // transcript=transcript.replace(' ','');
  //console.log("Transcript: ",transcript.replace(' ',''))
  var containsChar = myRe.exec(transcript.replace(' ',''));
  console.log(containsChar);
  
  if(!containsChar || $('#messageText').attr('type')=='password') {
	  transcript=transcript.replace(' ','');
	  console.log(transcript);	
  }
  
  // Add the current transcript to the contents of our Note.
  // There is a weird bug on mobile, where everything is repeated twice.
  // There is no official solution so far so we have to handle an edge case.
  var mobileRepeatBug = (current == 1 && transcript == event.results[0][0].transcript);

  if(!mobileRepeatBug) {
    noteContent= transcript;
    noteTextarea.val(noteContent);
	$('#chatbot-form').submit();
	//readOutLoud(noteContent);
  }
};

recognition.onend=function(event) {
	if($('i').attr('class')=='fa fa-microphone-slash') {
		console.log("Restarting after a long pause")
		recognition.start();
	}	
}

/*-----------------------------
      App buttons and input 
------------------------------*/

$('#chatbot-speech-btn').on('click', function(e) {
  if($('i').attr('class')=='fa fa-microphone') {
	  recognition.start();
	  console.log("Listening Started");
	  $('i').attr('class','fa fa-microphone-slash');
  }
  else {
	  recognition.stop();
	  console.log("Listening Stopped");
	  $('i').attr('class','fa fa-microphone');
  }
});


// Sync the text inside the text area with the noteContent variable.
noteTextarea.on('input', function() {
  noteContent = $(this).val();
})

/*-----------------------------
      Speech Synthesis 
------------------------------*/

function readOutLoud(message) {
	var speech = new SpeechSynthesisUtterance();

  // Set the text and voice attributes.
	speech.text = message;
	speech.volume = 1;
	speech.rate = 1;
	speech.pitch = 1;
  
	window.speechSynthesis.speak(speech);
}