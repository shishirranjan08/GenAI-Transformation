var app = angular.module("datawiz",[]);
app.controller("controller1", function($scope) {
  $scope.firstName = "John";
  $scope.lastName= "Doe";
});

app.directive('validUrl', function() {
  return {
    require: 'ngModel',
    link: function(scope, element, attr, mCtrl) {
      function myValidation(value) {
        var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
            '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.?)+[a-z]{2,}|'+ // domain name
            '((\\d{1,3}\\.){3}\\d{1,3}))'+ // ip (v4) address
            '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ //port
            '(\\?[;&amp;a-z\\d%_.~+=-]*)?'+ // query string
            '(\\#[-a-z\\d_]*)?$','i');
        console.log(value);
		if(value!="" && value!=undefined) {
			if(pattern.test(value)) {
				mCtrl.$setValidity('urlValidator', true);
			}
			else {
				mCtrl.$setValidity('urlValidator', false);
			}
		}
		else {
			mCtrl.$setValidity('urlValidator', true);			
		}
		return value;
      }
      mCtrl.$parsers.push(myValidation);
    }
  };
});

app.config(function($interpolateProvider){
	$interpolateProvider.startSymbol("[[");
	$interpolateProvider.endSymbol("]]");
});