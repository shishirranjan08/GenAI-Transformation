import json  
import logging  
import datetime  
from datetime import datetime
from flask import Flask, request, jsonify,render_template
from flask_cors import CORS  
from query_processor.plano_chatbot import AIAssistant  
import re  
import atexit  
import concurrent.futures 
import os
from app_logger import WegaLog
from service_bus_wrapper import send_message_to_queue


app = Flask(__name__)
# app.debug = True  
CORS(app)  
  
# Logging setup  
os.makedirs(os.path.join(os.getcwd(),"logs"), exist_ok=True)
current_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")  
log_file_name = os.path.join(os.getcwd(),"logs",f"wega_{current_time}.log") 
  
logging.basicConfig(level=logging.INFO,  
                    format='%(asctime)s %(levelname)s: %(message)s',  
                    datefmt='%Y-%m-%d %H:%M:%S',  
                    handlers=[logging.FileHandler(log_file_name), logging.StreamHandler()])  
logging.info("Starting WeGA app...")  
  
# assistant_en = AIAssistant("plano")  

try:
    with open("member_data_food_seating.json") as fp:
        member_data = json.load(fp)
except Exception as e:
    member_data = None



  
def check_json_format(input_json):  
    try:  
        input_dict = json.loads(input_json) if isinstance(input_json, str) else input_json  
  
        # Validate input JSON  
        assert isinstance(input_dict, dict), "Input JSON is not a dictionary"  
        chat_history = input_dict.get("chat_history", [])  
        query = input_dict.get("query", {})  
  
        assert isinstance(chat_history, list), "Chat history is not a list"  
        for chat in chat_history:  
            assert all(isinstance(chat.get(key), str) for key in ["role", "content", "timestamp"]), "Invalid chat format" 
            assert chat.get("role") in ["user", "assistant"], "Invalid role in chat history"   
  
        assert all(isinstance(query.get(key), str) for key in ["role", "content", "timestamp"]), "Invalid query format" 
        assert query.get("role") in ["user"], "Invalid role in query" 
  
        return "Input JSON format is correct"  
  
    except AssertionError as error:  
        raise ValueError(str(error)) 
  
  
def generate_response(bot_answer, wega_status):  
    return {  
        "wega_response": bot_answer,  
        'link': "",  
        "timestamp": "",  
        "wega_status": wega_status,  
        "meta_data": {  
            "reserved 1": "",  
            "reserved 2": ""  
        },  
        "ops_status": {  
            "start_time": "",  
            "end_time": ""  
        },  
        "resp_type": {  
            "type": "QA bot",  
            "reserved 1": "",  
            "reserved 2": ""  
        }  
    }  
  
  
# @app.before_request  
# def log_request_info():  
#     app.logger.info('Request JSON: %s', request.get_json())  
  
  
# @app.after_request  
# def log_response_info(response):  
#     app.logger.info('Response JSON: %s', response.get_json())  
#     return response  
  
  
@app.route('/', methods=['GET'])  
def index():  
    return 'Hi Welcome to WeGA(v1.0.8-271023)'
    #return render_template('chat.html')

@app.route('/wega_stream', methods=['POST'])
def index_response_stream():

    #app.logger.info('Request JSON: %s', request.form['query'])
    req_input_time = int(datetime.now().timestamp() * 1000)
    request_json = request.get_json()
    app.logger.info('Request JSON: %s', request.get_json())
    request_json = json.loads(request_json) if isinstance(request_json, str) else request_json
    wega_log = WegaLog(request_id=request_json['request_id'], user_info=request_json['user_info'], request_input=request_json,
                           request_input_timestamp=req_input_time)
    assistant_en = AIAssistant("UHGP_data")
    return assistant_en.answer_question_stream(request_json=request_json, wega_log=wega_log, 
                                               metadata = member_data.get(request_json['user_info'], None) if member_data != None else None)
  
@app.route('/wega_en', methods=['POST'])  
def index_response_en():
    assistant_en = AIAssistant("UHGP_data")
    return process_request(assistant_en)  
  
  
# @app.route('/wega_fr', methods=['POST'])  
# def index_response_fr():  
#     return process_request(assistant_fr)  
  
  
import concurrent.futures  

def process_request(assistant):
    req_input_time = int(datetime.now().timestamp() * 1000)
    request_json = request.get_json()
    app.logger.info('Request JSON: %s', request.get_json())   
    request_json = json.loads(request_json) if isinstance(request_json, str) else request_json 
    wega_log = WegaLog(request_id=request_json['request_id'], user_info=request_json['user_info'], request_input=request_json,
                           request_input_timestamp=req_input_time)
          
    try:  
        print(f"check_json_format : {check_json_format(request_json)}")  
  
        if check_json_format(request_json) == "Input JSON format is correct":  
            query_text = request_json['query']['content']  
            logging.info(f"request: {query_text}")
            wega_log.user_query = query_text
  
            with concurrent.futures.ThreadPoolExecutor() as executor:  
                future = executor.submit(assistant.answer_question, request_json)  
                try:  
                    wega_output = future.result(timeout=120)
                    wega_log.update_wega_response(wega_output)
                    # Print bot_response for debugging  
                    bot_response = wega_output['wega_response_raw']
                    print(f"bot_response: {bot_response}") 
                    bot_answer = bot_response.split("{")[0].strip()
                    resp_dict = generate_response(bot_answer, 200)
                    wega_log.wega_response = resp_dict
                    wega_log.wega_status_code = 200
                    app.logger.info('Response JSON: %s', json.dumps(resp_dict))
                    response_timestamp = int(datetime.now().timestamp() * 1000)
                    wega_log.response_timestamp = response_timestamp
                    wega_log.total_time = response_timestamp - req_input_time
                    app.logger.info("WeGA Log: "+ wega_log.to_json())
                    # send_message_to_queue(wega_log.to_json())
                    return jsonify(resp_dict)
                except concurrent.futures.TimeoutError:  
                    logging.warning("Processing request took too long.") 
                    msg = "I sincerely apologize for the inconvenience caused by the delayed response. \n" + "Please allow some time before attempting your request again, and I appreciate your patience and understanding."
                    timeout_response = generate_response(msg, 408)
                    app.logger.info('Response JSON: %s', json.dumps(timeout_response))
                    wega_log.wega_response = timeout_response
                    wega_log.wega_status_code = 408 
                    response_timestamp = int(datetime.now().timestamp() * 1000)
                    wega_log.response_timestamp = response_timestamp
                    wega_log.total_time = response_timestamp - req_input_time
                    app.logger.info("WeGA Log: "+ wega_log.to_json())
                    # send_message_to_queue(wega_log.to_json())
                    return jsonify(timeout_response)  
  
        else:  
            logging.warning(f"Invalid input JSON format: {request_json}")
            app.logger.info('Response JSON: %s', json.dumps(generate_response("Invalid input JSON format", 400)))
            return jsonify(generate_response("Invalid input JSON format", 400))  
  
    except Exception as e:
        msg = "I sincerely apologize for the inconvenience caused by the delayed response. \n" + "Please allow some time before attempting your request again, and I appreciate your patience and understanding."  
        internal_error_response = generate_response(msg, 500)
        app.logger.error(f"Error in processing request: {str(e)}", exc_info=True) 
        app.logger.info('Response JSON: %s', json.dumps(internal_error_response))
        wega_log.wega_response = internal_error_response
        wega_log.wega_status_code = 500
        response_timestamp = int(datetime.now().timestamp() * 1000)
        wega_log.response_timestamp = response_timestamp
        wega_log.total_time = response_timestamp - req_input_time
        app.logger.info("WeGA Log: "+ wega_log.to_json())
        # send_message_to_queue(wega_log.to_json())
        return jsonify(internal_error_response)  

  
def exit_handler():  
    logging.info("WeGA app is exiting...")  
    # assistant_en.end_connection()
  
  
if __name__ == '__main__':  
    # atexit.register(exit_handler)  
    app.run(host="0.0.0.0", port=5000, debug=False)  
 