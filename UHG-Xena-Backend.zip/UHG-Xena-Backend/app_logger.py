from dataclasses import dataclass
from dataclasses_json import dataclass_json
from typing import Optional

# 1. Request ID
# 2. user_info
# 3. request_json
# 4. user_query
# 5. wega_user_rephrased_query
# 6. req_input_time
# 7. wega_user_context
# 8. wega_

@dataclass_json
@dataclass
class WegaLog:
    request_id: str
    request_input: dict
    request_input_timestamp: int
    user_query: Optional[str]=None
    user_info: Optional[str] = None 
    wega_user_rq: Optional[str]  = None
    wega_user_rq_start_timestamp: Optional[int]  = None
    wega_user_rq_end_timestamp: Optional[int]  = None
    wega_user_rq_totaltime: Optional[int]  = None
    wega_user_context: Optional[str]  = None
    wega_response_raw: Optional[str]  = None
    wega_response_raw_start_timestamp: Optional[int]  = None
    wega_response_raw_end_timestamp: Optional[int]  = None
    wega_response_raw_totaltime: Optional[int]  = None
    wega_response: Optional[dict]  = None
    wega_status_code: Optional[str]  = None
    wega_query_emb_start_timestamp: Optional[int]  = None
    wega_query_emb_end_timestamp: Optional[int]  = None
    wega_query_emb_totaltime: Optional[int]  = None
    response_timestamp: Optional[int]  = None
    total_time: Optional[int]  = None
    wega_step_count: Optional[int]  = None
    wega_stream_chunk_time: Optional[list] = None
    wega_response_raw_stream: Optional[bool] = False
    wega_response_raw_deployment_name: Optional[str]=None
    

    def update_wega_response(self, wega_output):
        wega_log = self
        wega_log.wega_response_raw = wega_output['wega_response_raw']
        wega_log.wega_user_rq = wega_output['wega_user_rq']
        wega_log.wega_user_rq_start_timestamp = wega_output['wega_user_rq_start_timestamp']
        wega_log.wega_user_rq_end_timestamp = wega_output['wega_user_rq_end_timestamp']
        wega_log.wega_user_rq_totaltime = wega_output['wega_user_rq_end_timestamp'] - wega_output['wega_user_rq_start_timestamp']

        wega_log.wega_user_context = wega_output['wega_user_context']
        wega_log.wega_query_emb_start_timestamp = wega_output['wega_query_emb_start_timestamp']
        wega_log.wega_query_emb_end_timestamp = wega_output['wega_query_emb_end_timestamp']
        wega_log.wega_query_emb_totaltime = wega_output['wega_query_emb_end_timestamp'] - wega_output['wega_query_emb_start_timestamp']

        wega_log.wega_response_raw_start_timestamp = wega_output['wega_response_raw_start_timestamp']
        wega_log.wega_response_raw_end_timestamp = wega_output['wega_response_raw_end_timestamp']
        wega_log.wega_response_raw_totaltime = wega_output['wega_response_raw_end_timestamp'] - wega_output['wega_response_raw_start_timestamp']
    