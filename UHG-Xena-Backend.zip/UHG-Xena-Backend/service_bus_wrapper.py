from azure.servicebus import ServiceBusClient, ServiceBusMessage

# from azure.servicebus.aio import ServiceBusClient
# from azure.servicebus import ServiceBusMessage


import os
connstr = "Endpoint=sb://aicoe-openai-throttling.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=YULSYxDhO/9u/kfhcnUakFSR5zbblDOUI+ASbNWY7fs="
queue_name = "queue-wega-xena-logs"
import logging 

# async def send_single_message(sender, msg: str):
#     # Create a Service Bus message and send it to the queue
#     message = ServiceBusMessage(msg)
#     await sender.send_messages(message)
#     print("Sent a single message")

def send_message_to_queue(msg):
    try:
        with ServiceBusClient.from_connection_string(connstr) as client:
            with client.get_queue_sender(queue_name) as sender:
                message = ServiceBusMessage(msg)
                sender.send_messages(message)
    except Exception as e:
        logging.info("Unable to send message to Service Bus %s", str(e))
        pass

    
    
# async def run(msg):
#     # create a Service Bus client using the credential
#     async with ServiceBusClient.from_connection_string(connstr) as servicebus_client:
#         # get a Queue Sender object to send messages to the queue
#         sender = servicebus_client.get_queue_sender(queue_name=queue_name)
#         async with sender:
#             # send one message
#             await send_single_message(sender, msg=msg)

