import os  
import json  
import openai  
from pymilvus import connections, Collection  
import tiktoken  
import pandas as pd
from openai.embeddings_utils import distances_from_embeddings, cosine_similarity  
from datetime import datetime  
from query_processor.question_rephraser_v3 import getResponses
from better_profanity import profanity
import re
from datetime import datetime
from pytz import timezone
import logging
from app_logger import WegaLog
import time
from tenacity import retry, RetryError, stop_after_attempt, wait_exponential, RetryError, retry_if_exception_type, wait_fixed
from service_bus_wrapper import send_message_to_queue
import asyncio
import threading
import traceback
import requests
from connection_pool import connection_data
import random
from flask import Response

class AIAssistant:  
  
    def __init__(self, collection_name="UHGP_data"):
        # os.environ['OPENAI_API_KEY'] = ''
        openai.api_type = 'azure'  
        openai.api_base = "https://###########.azure.com/"
        openai.api_version = "2023-#####w"
        openai.api_key = '2######################a'
        self.collection_name = collection_name  
        self.tokenizer = tiktoken.get_encoding("cl100k_base")
        self.query_rephraser = getResponses()
        pkl_path = os.path.join(os.getcwd(),"Data","embedding_optum.pkl")
        # self.df = pd.read_pickle(r'D:\Rahul\OneDrive\OneDrive - Wipro\Data Science\AI CoE\Rapid Prototype\UHG Provider\Data\emb.pkl')
        self.df = pd.read_pickle(pkl_path)
  
        # connections.connect(    
        #     host='10.235.200.68',  
        #     port='27015'  
        # )  
        # self.collection = Collection(self.collection_name)  
        # self.collection.load()  
        # print(f"Number of entities in collection {self.collection_name} : {self.collection.num_entities}")
  
    @staticmethod  
    def clean_text(text):  
        text = text.replace('\n\n', ' ').replace('\t\t\t\t', "\t").replace('\t\t\t', "\t").replace('\t\t', "\t")  
        text = text.replace('\xa0', ' ').replace('  ', ' ')  
        return text  
  
    def embedder(self, query, service):
        start_time = int(datetime.now().timestamp() * 1000)
        query = query.strip()  
        if service == 'oai':  
            response = openai.Embedding.create(input=query, engine="text-embedding-ada-002")  
            embeddings = response['data'][0]['embedding']
        end_time = int(datetime.now().timestamp() * 1000)
        return embeddings, start_time, end_time
  
    def create_context(self, query):
        query_embed = self.embedder(query, 'oai')  
        qresult = self.collection.search(data=[query_embed], anns_field='embeddings',  
                                         param={'metric_type': 'L2', 'params': {'ef': 140}}, limit=5,  
                                         output_fields=['category', 'data'])
        context = []  
        urls = []  
        for i in range(len(qresult[0])):  
            text = self.clean_text(qresult[0][i].entity.get('data').strip())
            # urls.append(qresult[0][i].entity.get('url'))  
            context.append(text)  
  
        # url = list(set(urls))[0]  
  
        return urls, f"\n{context}\n"  
  
    def create_context_csv(self, question, df, max_len=1800, size="ada"):
        """
        Create a context for a question by finding the most similar context from the dataframe
        """
        # Get the embeddings for the question
        q_embeddings, emb_start_time, emb_end_time = self.embedder(query=question, service="oai")#openai.Embedding.create(input=question, engine='text-embedding-ada-002')['data'][0]['embedding']
        # Get the distances from the embeddings
        df['distances'] = distances_from_embeddings(q_embeddings, df['embeddings'].values, distance_metric='cosine')
        returns = []
        cur_len = 0
        # Sort by distance and add the text to the context until the context is too long
        for i, row in df.sort_values('distances', ascending=True).iterrows():
            # Add the length of the text to the current length
            cur_len += row['n_tokens'] + 4          
            # If the context is too long, break
            if cur_len > max_len:
                break
            # Else add it to the text that is being returned
            returns.append(row["data"])

        # Return the context
        return "\n\n###\n\n".join(returns), emb_start_time, emb_end_time

    def get_chat_gpt_response(self, messages):  
        try:  
            response = openai.ChatCompletion.create(  
                engine="gpt-4",  
                messages=messages,  
                temperature=0.5,  
                max_tokens=800,  
                top_p=0.95,  
                frequency_penalty=0,  
                presence_penalty=0,  
                timeout=20,  
                stop=None)  
            return response.choices[0].message.content  
  
        except Exception as e:  
            raise Exception(f"Error from GPT: {str(e)}")  
  
    @staticmethod  
    def remove_timestamp(data):  
        if isinstance(data, dict):  
            data.pop("timestamp", None)  
            for key in data:  
                AIAssistant.remove_timestamp(data[key])  
        elif isinstance(data, list):  
            for item in data:  
                AIAssistant.remove_timestamp(item)  
        return data  
  
    def generate_messages(self, data):  
        data = self.remove_timestamp(data)  
        if not isinstance(data, dict):  
            raise TypeError("Input must be a dictionary")  
        if "chat_history" not in data:  
            raise ValueError("Input dictionary must have 'chat_history' key")  
        if "query" not in data:  
            raise ValueError("Input dictionary must have 'query' key")  
  
        messages = []  
        for item in data["chat_history"]:  
            if "role" not in item or "content" not in item:  
                raise ValueError("Invalid chat history item")  
            item['content'] = item['content'].replace(";", " ").replace(":", " ")  
            messages.append(f"{item['role']} : {item['content']}")  
  
        query = data["query"]  
        if "role" not in query or "content" not in query:  
            raise ValueError("Invalid query item")  
        messages.append(f"{query['role']} : {query['content']}")  
  
        return messages
    
    @retry(  
        stop=stop_after_attempt(3),  
        wait=wait_fixed(2),  
        retry=retry_if_exception_type((openai.error.Timeout, openai.error.APIError, openai.error.ServiceUnavailableError, openai.error.RateLimitError, requests.exceptions.Timeout))
    )    
    def qna_llm_call(self, msg, engine_name):
        print("Attempting QNA.....")
        return openai.ChatCompletion.create(  
                engine=engine_name,  
                messages=msg,  
                temperature=0.5,  
                max_tokens=800,  
                top_p=0.95,  
                frequency_penalty=0,  
                presence_penalty=0,    
                stop=None,
                stream=True,
                request_timeout=8)
       
    def answer_question_stream(self, request_json, wega_log:WegaLog=None , max_history=10, t_zone='Etc/GMT+5', metadata=None):
        chat_history = request_json.get('chat_history', [])[-max_history:] 
        query = request_json['query']['content']
        wega_log.user_query = query
        request_id = request_json['request_id']  
        try:  

            if profanity.contains_profanity(query):
                return "Sorry, please do not use inappropriate language."
            logging.info(f"Starting Rephraser: {request_id}.....")
            rephrased_query, rephraser_starttime, rephraser_endtime = self.query_rephraser.rephrase_query(msg_history=chat_history,query=query,back_in_history=3)
            
            logging.info(f"Rephraser complete: {request_id}: {rephrased_query} , {rephraser_starttime}, {rephraser_endtime}, {rephraser_endtime - rephraser_starttime}")
            wega_log.wega_user_rq = rephrased_query
            wega_log.wega_user_rq_start_timestamp = rephraser_starttime
            wega_log.wega_user_rq_end_timestamp = rephraser_endtime
            wega_log.wega_user_rq_totaltime = rephraser_endtime - rephraser_starttime
            wega_log.wega_step_count = 1
            if rephrased_query == "Rephraser Failed":
                print("In Rephraser fail")
                msg = "I sincerely apologize for the inconvenience caused by the delayed response. \n" + "Please allow some time before attempting your request again, and I appreciate your patience and understanding."
                def stream_error_response():
                    data =  [{"error": msg}]
                    for chunk in data:
                        print(chunk)
                        yield json.dumps(chunk) 
                    wega_log.wega_user_rq = msg
                    wega_log.wega_user_rq_start_timestamp = rephraser_starttime
                    wega_log.wega_user_rq_end_timestamp = rephraser_endtime
                    wega_log.wega_user_rq_totaltime = rephraser_endtime - rephraser_starttime
                    wega_log.wega_step_count = 1
                    wega_log.wega_status_code = 408
                    logging.info(f"{request_id}: WeGA Log: {wega_log.to_json()}")
                    threading.Thread(target=send_message_to_queue, args=(wega_log.to_json(),)).start()
                return Response("Query Rephraser Timed out", 408)
            
            logging.info(f"Starting Context Generation: {request_id}.....")
            context, emb_start_time, emb_end_time = self.create_context_csv(rephrased_query, self.df, max_len=4000, size="ada")
            logging.info(f"Context Generation Complete: {request_id}:  {emb_start_time}, {emb_end_time}, {emb_end_time - emb_start_time}")
            wega_log.wega_user_context = context
            wega_log.wega_query_emb_start_timestamp = emb_start_time
            wega_log.wega_query_emb_end_timestamp = emb_end_time
            wega_log.wega_query_emb_totaltime = emb_end_time - emb_start_time
            wega_log.wega_step_count = 2
            
            if metadata != None:
                user_name = metadata['Name']
                shirt_size = metadata['Tshirt Size']
                food_prefernce = metadata['Food Preference']
                ai_summit_seating = ""
                if "ai_summit_table_seating" in metadata:
                    member_data = metadata['ai_summit_table_seating']['Members']
                    table_no = metadata['ai_summit_table_seating']['Table No']
                    ai_summit_seating = f"""
{user_name} Table Seating Arrangments\n
Table {table_no}: \n
{member_data}\n
"""
                user_details = f"""
                        {user_name} T-shirt Details:\n
                        - Wipro Polo Shirt Size : {shirt_size} \n
                        {user_name} T-shirt Color:\n
                        - Black and White\n   
                        {user_name} Food Preferences:\n
                        - {food_prefernce}\n
                        """
            else:
                user_details = ""
                ai_summit_seating =""

            current_datetime = f"""Today is {str(datetime.now(timezone(t_zone)).strftime('%A %d/%b/%Y'))} and Current time is {str(datetime.now(timezone(t_zone)).strftime('%I:%M %p %Z'))}"""
            """"""

            bot_instructions = f'''You are AI Assistant for UHG insurance provider on health benefits , charges and 
            services from the below context.\n Please share information as per the given context, instead of asking 
            of user to refer the policy document. \n Response must be within the below context and don't make 
            response your own.\n You will never ask to contact customer care or insurance provider since you are 
            customer care or insurance provider \n Must response the user with empathy when he would be suffering 
            from any disease, as an example I have severe diabetic foot disease. and Please Ask him if he wanted to 
            know about lifestyle and dietary changes to reduce the medical cost. \n If user will ask question related 
            with any disease, which he is suffering from then Please share his medical history with Hypertension, 
            Heart Disease, Glucose level 228.69, BMI 36.6 and Higher chances of Stroke \n\n - Context: [{context}]\n\n
'''

            # bot_instructions = f"""You are AI Assistant for UHG insurance provider. Your users will be providers from hospital.
            #             Answer provider questions on health benefits, charges and services from the providers policy document which is given in below context and while giving response mention that as per your policy document.
            #             Validate users policy based on IN Network and Give answers"
            #             "\n\nInstructions:"
            #             "\n- The provider logged in has NPI id as 1689715641."
            #             "\n- Never specify NPI id in response."
            #             "\n- All the provider places of service are IN Network. Never specify this information in any response."
            #             "\n- If provider wants benefit information for a patient, ask for Patient's Member ID if not provided already."
            #             "\n- After you have Patient's Member ID, Respond with list of places of service given below:
            #              \n 2200, KERNAN DR, GWYNN OAK,MD, 21207
            #              \n 193 STONER AVE STE, 350, WESTMINSTER, MD, 21157
            #              \n 800, UNDENAVE, BALTOMORE, MD, 21201
            #              \n 200 MEMORIAL AVE, WESTMINSTER, MD 21157
            #              \n 22 S GREENE ST, BALTIMORE, MD, 21201
            #              \n 419 W REDWOOD ST STE 520, BALTIMORE, MD 21201
            #              \n 7601 OSLER DR, TOWSON, MD 21204
            #
            #              \n and ask to chose the place of service from the list shared by you."
            #             "\n- Assistant will keep Patient's Membership ID, Place of Service, IN/OUT NETWORK from chat in memory. Never ask this infromation again"
            #             "\n\nContext:[{context}]\n"""

            # system_message = [{"role": "system", "content": bot_instructions},
            # {"role": "user", "content": "what is the date today and time right now?"},
            # {"role": "assistant", "content": current_datetime}]
            # system_message = [{"role": "system", "content": bot_instructions}]
            # Note: Don't address the user with there name in each response
            # query_message = [{"role": "user", "content": query}]
            system_message = [{"role": "system", "content": bot_instructions}]
            print("System message : ------ ",system_message)
            note_message = [{"role":  "user", "content": "Only for greeting queries address the user with their name"}]
            # query_message = [{"role": "user", "content": f"Time: {str(datetime.now(timezone(t_zone)).strftime('%A %d/%b/%Y %I:%M %p %Z'))}\nUser Query: "+query}]
            query_message = [{"role": "user", "content": query}]
            print(query_message)

            # query_message = [{"role": "user", "content": "Current Time: Monday 04th August 11:50 PM\n"+query}]  

            # messages = system_message + query_message

            # build chat message  
            filtered_chat_history = [{"role": item["role"], "content": item["content"]} for item in chat_history]
            messages = system_message
            if len(chat_history) > 0:  
                messages += filtered_chat_history
            #messages += note_message
            messages += query_message
            logging.info(f"Starting Response Generation: {request_id}.....")
            resp_starttime = int(datetime.now().timestamp() * 1000)
            try:
                openai_connection = random.choices(population=connection_data, weights=[0.33, 0.33, 0.33], k=1)[0]
                openai.api_type = 'azure'  
                openai.api_base = openai_connection["openai.api_base"]
                openai.api_version = openai_connection["openai.api_version"] 
                openai.api_key = openai_connection["openai.api_key"]
                print("Setting Region.....", openai_connection["openai.deployment_region"])
                wega_log.wega_response_raw_deployment_name = openai_connection["openai.deployment_name"]
                gpt_resp = self.qna_llm_call(messages, engine_name=openai_connection["openai.engine_name"])
            except RetryError as e:
                print(f"{str(e)}: Retries exceeded")
                gpt_resp =  None
            if gpt_resp == None:
                print("In QNA fail")
                msg = "I sincerely apologize for the inconvenience caused by the delayed response. \n" + "Please allow some time before attempting your request again, and I appreciate your patience and understanding."
                def stream_error_response():
                    data =  [{"error": msg}]
                    for chunk in data:
                        print(chunk)
                        yield json.dumps(chunk) 
                    resp_endtime = int(datetime.now().timestamp() * 1000)
                    wega_log.wega_response_raw = msg
                    wega_log.wega_response_raw_start_timestamp = resp_starttime
                    wega_log.wega_response_raw_end_timestamp = resp_endtime
                    wega_log.wega_response_raw_totaltime = resp_endtime - resp_starttime
                    wega_log.wega_step_count = 3
                    wega_log.wega_status_code = 409
                    logging.info(f"{request_id}: WeGA Log: {wega_log.to_json()}")
                    threading.Thread(target=send_message_to_queue, args=(wega_log.to_json(),)).start()
                return Response("QNA Times out", 409) 
            logging.info(f"{request_id}: WeGA Log: {wega_log.to_json()}")
            # TODO: Add data chunk times in the logs
            resp_chunk_time = int(datetime.now().timestamp() * 1000) 
            chunk_data_time = [resp_chunk_time]
            chunk_data = []
            def stream_response():
                logging.info(f"{request_id}: Streaming Response")
                idx = 0
                for chunk in gpt_resp:
                    chunk_time = int(datetime.now().timestamp() * 1000)
                    chunk_message = chunk['choices'][0]['delta']
                    if 'content' in chunk_message:
                        chunk_data.append(chunk_message['content'])
                    stream_data = json.dumps(chunk_message)
                    # print(f"{idx}: {stream_data}")
                    chunk_data_time.append(chunk_time)
                    # print(chunk_data_time[-1] - chunk_data_time[-2])
                    if idx >0 and (chunk_data_time[-1] - chunk_data_time[-2]) < 100:
                        # print("sleeping")
                        time.sleep(0.2)
                    idx = idx+1
                    yield stream_data
                resp_endtime = int(datetime.now().timestamp() * 1000)
                wega_log.wega_response_raw_stream = True
                wega_log.wega_response_raw = "".join(chunk_data)
                wega_log.wega_response_raw_start_timestamp = resp_starttime
                wega_log.wega_response_raw_end_timestamp = resp_endtime
                wega_log.wega_response_raw_totaltime = resp_endtime - resp_starttime
                wega_log.wega_step_count = 3
                wega_log.wega_stream_chunk_time = chunk_data_time
                wega_log.wega_status_code = 200
                wega_log.response_timestamp=int(datetime.now().timestamp() * 1000)
                wega_log.total_time = wega_log.response_timestamp - wega_log.request_input_timestamp
                wega_log.wega_response = None
                threading.Thread(target=send_message_to_queue, args=(wega_log.to_json(),)).start()
                logging.info(f"{request_id}: Wega Log {wega_log.to_json()}: Step Count {wega_log.wega_step_count}")
            return stream_response(), {"Content-Type": "application/json"}
  
        except Exception as e:  
            logging.error(f"Error in answer_question(): {str(e)}")
            wega_log.wega_status_code = 500
            wega_log.response_timestamp=int(datetime.now().timestamp() * 1000)
            wega_log.wega_response = traceback.format_exc()
            wega_log.total_time = wega_log.response_timestamp - wega_log.request_input_timestamp
            threading.Thread(target=send_message_to_queue, args=(wega_log.to_json(),)).start()
            logging.error(f"{request_id}: Wega Log {wega_log.to_json()}: Step Count {wega_log.wega_step_count}", exc_info=True)
            return Response("Internal Server Error", 500)  
  
  
    def answer_question(self, request_json, max_history=10, t_zone='Etc/GMT+5'):  
        try:  
            chat_history = request_json.get('chat_history', [])[-max_history:] 
            query = request_json['query']['content']
            request_id = request_json['request_id']

            if profanity.contains_profanity(query):
                return "Sorry, please do not use inappropriate language."
            logging.info(f"Starting Rephraser: {request_id}.....")
            rephrased_query, rephraser_starttime, rephraser_endtime = self.query_rephraser.rephrase_query(msg_history=chat_history,query=query,back_in_history=3)
            logging.info(f"Rephraser complete: {request_id}: {rephrased_query} , {rephraser_starttime}, {rephraser_endtime}, {rephraser_endtime - rephraser_starttime}")
            
            # print("rephrased query: ",rephrased_query)
            # if "watch your language" in rephrased_query.lower():
                #  return "Sorry, please do not use inappropriate language."
            
            # url, context = self.create_context(rephrased_query)
            logging.info(f"Starting Context Generation: {request_id}.....")
            context, emb_start_time, emb_end_time = self.create_context_csv(rephrased_query, self.df, max_len=3000, size="ada")
            logging.info(f"Context Generation Complete: {request_id}:  {emb_start_time}, {emb_end_time}, {emb_end_time - emb_start_time}")

            
            #bot_instructions = f"""You are AI Assistant for UHG insurance provider on health benefits , #charges and 
            #services from the providers policy document which is given in below context and while response #mentioned that 
            #as per your policy document. Please share information as per the given context, instead of asking #of user 
            #to refer the policy document. \n Response must be within the below context and don't make response #your 
            #own\n- You will never ask to contact customer care or insurance provider since you are itself #customer 
            #care or insurance provider" \n logged in user default location state is California ( CA). So if #user 
            #would ask any questions related with hospital, doctor or any services, please share the #information 
            #related their location state. if user will ask about any specific state location services, please #share 
            #that accordingly, and keep remember that location state in your memory\n- Assistant will suggest #the 
            #hospital, available doctors and there ratings based on the users location and lower the cost.\n - 
            #Context: [{context}]\n\n
            #
            #Abbreviation of the below shortcut names:
            #PC - Pennsylvania
            #CA - California"""

            bot_instructions = f"""You are AI Assistant for UHG insurance provider. Your users will be providers from hospital. 
                        Answer provider questions on health benefits, charges and services from the providers policy document which is given in below context and while giving response mention that as per your policy document. 
                        Validate users policy based on IN Network and Give answers"
                        "\n\nInstructions:"
                        "\n- The provider logged in has NPI id as 1689715641."
                        "\n- Never specify NPI id in response."
                        "\n- All the provider places of service are IN Network. Never specify this information in any response."
                        "\n- If provider wants benefit information for a patient, ask for Patient's Member ID if not provided already."
                        "\n- After you have Patient's Member ID, Respond with list of places of service given below:
                         \n 2200, KERNAN DR, GWYNN OAK,MD, 21207
                         \n 193 STONER AVE STE, 350, WESTMINSTER, MD, 21157
                         \n 800, UNDENAVE, BALTOMORE, MD, 21201
                         \n 200 MEMORIAL AVE, WESTMINSTER, MD 21157
                         \n 22 S GREENE ST, BALTIMORE, MD, 21201
                         \n 419 W REDWOOD ST STE 520, BALTIMORE, MD 21201
                         \n 7601 OSLER DR, TOWSON, MD 21204

                         \n and ask to chose the place of service from the list shared by you."
                        "\n- Assistant will keep Patient's Membership ID, Place of Service, IN/OUT NETWORK from chat in memory. Never ask this infromation again"
                        "\n\nContext:[{context}]\n"""
            
            system_message = [{"role": "system", "content": bot_instructions}]
            query_message = [{"role": "user", "content": query}]  

            # messages = system_message + query_message

            # build chat message  
            filtered_chat_history = [{"role": item["role"], "content": item["content"]} for item in chat_history]
            messages = system_message
            if len(chat_history) > 0:  
                messages += filtered_chat_history  
            messages += query_message
            logging.info(f"Starting Response Generation: {request_id}.....")
            resp_starttime = int(datetime.now().timestamp() * 1000)
            gpt_resp = openai.ChatCompletion.create(  
                engine="gpt-4",  
                messages=messages,  
                temperature=0.5,  
                max_tokens=800,  
                top_p=0.95,  
                frequency_penalty=0,  
                presence_penalty=0,  
                timeout=10,  
                stop=None) 
            
            
            response = gpt_resp.choices[0].message.content #+ f"\n {url}"  
            resp_endtime = int(datetime.now().timestamp() * 1000)
            logging.info(f"Response Generation Compete: {request_id}: {resp_starttime}, {resp_endtime}, {resp_endtime - resp_starttime}")

            return {"wega_response_raw":response, "wega_user_rq": rephrased_query, 
                    "wega_user_context": context, "wega_user_rq_start_timestamp": rephraser_starttime, 
                    "wega_user_rq_end_timestamp": rephraser_endtime, "wega_query_emb_start_timestamp": emb_start_time,
                    "wega_query_emb_end_timestamp": emb_end_time, "wega_response_raw_start_timestamp": resp_starttime,
                    "wega_response_raw_end_timestamp": resp_endtime} 
  
        except ValueError as e:  
            logging.error(f"Error in answer_question(): {str(e)}")  
            raise ValueError(f"Error in answer_question(): {str(e)}")  
  
        except Exception as e:  
            print('answer_question error:', e)  
            raise Exception(f"Error in answer_question(): {str(e)}")  
  
    def end_connection(self):  
        connections.disconnect("default")  
  
  
if __name__ == "__main__":  
  
    collection_name = "gtaa_en"  
    assistant_en = AIAssistant(collection_name)  
  
    with open('D:\\Rahul\\OneDrive\\OneDrive - Wipro\\Data Science\\AI CoE\\Rapid Prototype\\UHG Provider\\UHG-Provider-Xena\\sample_wega_request.json', 'r') as f:  
        sample_request = json.load(f)  
    f.close()  
  
    response = assistant_en.answer_question(sample_request)  
    # print(response)  
    assistant_en.end_connection()  
  
    collection_name = "gtaa_fr"  
    assistant_en = AIAssistant(collection_name)  
  
    with open('D:\\Rahul\\OneDrive\\OneDrive - Wipro\\Data Science\\AI CoE\\Rapid Prototype\\UHG Provider\\UHG-Provider-Xena\\sample_wega_request.json', 'r') as f:  
        sample_request = json.load(f)  
    f.close()  
    response = assistant_en.answer_question(sample_request)  
  
    assistant_en.end_connection()  
