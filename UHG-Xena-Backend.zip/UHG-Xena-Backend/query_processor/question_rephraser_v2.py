#Note: The openai-python library support for Azure OpenAI is in preview.
import os
import openai
import traceback
os.environ['OPENAI_API_KEY'] = '#########a'
openai.api_type = 'azure'  
openai.api_base = "https://###########.azure.com/"
openai.api_version = "2023-######view"
openai.api_key = os.getenv("OPENAI_API_KEY")  

class getResponses:  
    def __init__(self):  
        self.prompt_msg =   [
            {"role":"system","content":"""Rephrase the input_query with minimum but relevant entities, nouns and context if required.
Description: In this task, you'll be working with a chatbot that takes into account input_query asked by the user and old_chat between user and AI during the chat session. Your goal is to rephrase the input_query asked by the user if required , making sure to include required nouns, entities and context if required. This way, the rephrased question will be self-sufficient for a QnA bot to answer input query .
Instructions:
1. If there are any offensive and bad words or phrases in input_query, reply with - "WATCH YOUR LANGUAGE". Otherwise, follow below instructions.
2. Read through user's input_query and previous relevant old_chat between user and AI (from older to newer) and rephrase the input_query accordingly, paying close attention to previous queries and their context.
3. Understand the input_query asked by the user. 
4. If required, rephrase the input_query to include any necessary information from previous queries.
5. Ensure that the rephrased question is clear, concise, and can be answered by a QnA bot.
6. Do not change the intend of input_query. You must rephrase input_query, refrain yourself to frame answers.
"""}
            ]

        # self.examples = [
        #     {"role":"user","content":"input_query: who is first to step foot on it?\n\nold_chat: <user>:Tell me something about NASA.<AI>:NASA is the acronym for the National Aeronautics and Space Administration, a US government agency responsible for the country's civilian space program and for aeronautics and aerospace research. It was established in 1958 and has been involved in numerous space exploration missions, including the Apollo Moon landing program and the Space Shuttle program.<User>: Which mission successfully put man on moon? <AI>:The Apollo 11 mission, launched by NASA in 1969, successfully landed astronauts Neil Armstrong and Edwin \"Buzz\" Aldrin on the Moon's surface. This was the first time humans had ever set foot on another celestial body."},
        #     {"role":"assistant","content":"Who was the first person to step foot on the Moon?"},
        #     {"role":"user","content":"input_query: Tell me the name of that parking lot.\n\nold_chat: <AI>:Hi, How are you? <user>:How many terminals does Delhi airport have? <AI>: The Indira Gandhi International Airport in Delhi has three terminals: Terminal 1, Terminal 2, and Terminal 3. <user>: Do we have any lounges at terminal 2? <AI>: Yes, there are lounges available at Terminal 2 of the Indira Gandhi International Airport in Delhi. Some of the lounges include the Plaza Premium Lounge, the ITC Lounge, and the Allways Lounge. <user>: Tell me about parking lot at T2. <AI>: The Terminal 2 of Indira Gandhi International Airport in Delhi has a multi-level car parking facility for passengers and visitors. The parking lot can accommodate up to 2,200 cars and is located opposite to the terminal building. The parking rates vary depending on the duration of parking, and there are both hourly and daily parking options available. Payment can be made using cash, credit/debit card, or via a mobile app."},
        #     {"role":"assistant","content":"Tell me the name of the parking lot next to terminal 2 of Delhi airport."},
        #     {"role":"user","content":"input_query: Tell me about parking lot at T2.\n\nold_chat: <user>: Hi, How are you? <AI>: Hello! As an AI language model, I don't have feelings, but I'm functioning as intended and ready to assist you. How can I help you today? <user>: How many terminals does Delhi airport have? <AI>: The Indira Gandhi International Airport in Delhi has three terminals: Terminal 1, Terminal 2, and Terminal 3. <user>: Do we have any lounges at terminal 2? <AI>: Yes, there are lounges available at Terminal 2 of the Indira Gandhi International Airport in Delhi. Some of the lounges include the Plaza Premium Lounge, the ITC Lounge, and the Allways Lounge."},
        #     {"role":"assistant","content":"Tell me about the parking lot at Terminal 2 of Delhi airport."},
        #     {"role":"user","content":"input_query: Hi\n\nold_chat:"},
        #     {"role":"assistant","content":"Hi"},
        #     {"role":"user","content":"input_query: How I can create snow ball?\n\nold_chat:"},
        #     {"role":"assistant","content":"How can I create a snowball?"},
        #     {"role":"user","content":"input_query: What are the charges for Lasik surgery? I am covered under Humana PPO\n\nold_chat: <user>: I have subscribed to Humana PPO, am I covered for dental transplant? <AI>: Humana PPO plans may provide coverage for dental procedures, including dental transplants, depending on the specific plan you are enrolled in. However, coverage may be subject to certain limitations and exclusions, so it's important to review your plan's benefits and coverage details or contact Humana customer service to confirm coverage for a dental transplant. <user>: What will be the charges? <AI>: The charges for a dental transplant can vary depending on various factors, such as the location, the dentist or oral surgeon providing the procedure, and the complexity of the case. Additionally, coverage for the procedure under your Humana PPO plan may also affect the out-of-pocket costs you would pay. It's best to check with your dentist or oral surgeon and Humana customer service to get an estimate of the charges and your coverage for the procedure. <user>: What all clinics are near me for this procedure? <AI>: There are several clinics in New York City that offer dental transplant procedures. Some of the clinics that you may consider include Columbia University College of Dental Medicine, New York University College of Dentistry, Mount Sinai Hospital, and New York Presbyterian Hospital. It's recommended to consult your dentist or oral surgeon for a referral or to do your research and compare the services, reputation, and costs of different clinics before deciding on one."},
        #     {"role":"assistant","content":"What is the cost of Lasik surgery for a patient covered under Humana PPO?"},
        #     {"role":"user", "content":"input_query: you shitty piece of junk, answer me!\n\nold_chat:"},
        #     {"role":"assistant", "content":"WATCH YOUR LANGUAGE"}
        #     ]
        self.examples = []
        self.engine = "gpt-4"  
        self.temperature = 0.5 
        self.max_tokens = 200  
        self.top_p = 0.95  
        self.frequency_penalty = 0  
        self.presence_penalty = 0  
        self.stop = None  
  
    @staticmethod  
    def create_message(prompt, examples, input_query):  
        # prompt.extend(examples)  
        # prompt.append(input_query)  
        return prompt+examples+[input_query]  
      
    def llm(self, message):  
        return openai.ChatCompletion.create(  
            engine=self.engine,  
            messages=message,  
            temperature=self.temperature,  
            max_tokens=self.max_tokens,  
            top_p=self.top_p,  
            frequency_penalty=self.frequency_penalty,  
            presence_penalty=self.presence_penalty,  
            stop=self.stop,  
        )  
        
    def rephrase_query(self, msg_history, query, back_in_history=0):
        no_of_last_msges = -back_in_history*2
        old_msges = []
        try:
            for msg in msg_history:
                if msg["role"] == "user":
                    old_msges.append("<user>: {}".format(msg["content"]))
                else:
                    old_msges.append("<AI>: {}".format(msg["content"]))
        except:
            traceback.print_exc()
        
        # old_msges.reverse()
        old_queries = " ".join(old_msges[no_of_last_msges:])
        query_stack = {"role":"user", "content":"input_query: {}\n\nold_queries: {}".format(query, old_queries)}
        print("\n\n\n", query_stack, "\n\n\n")
        message = self.create_message(self.prompt_msg, self.examples, query_stack) 
        return self.llm(message)["choices"][0]["message"]["content"]
    
    def create_query(self, query):
        return {"role": "user", "content":"{}".format(query)}
        
  
if __name__ == "__main__":  
    gpt_complete = getResponses()  
    # gpt_complete.engine = "chatgpt"
    # query = [{"role": "user", "content": "1. How to raise request for travel?  \n2. Can I fly business? I am B3?  \n3. What about D2?  \n4. How to raise request for planned leaves?  \n5. How many leaves am I entitled to?"}] 
    #query_txt = gpt_complete.get_queries(old_messages)
    query = gpt_complete.create_query("input_query: How do I got to gate 39 ?\n\nold_queries: 1. Flight status\n2. ac105\n3. hi\n4. where to find wheelchair")#  \n4. How to raise request for planned leaves?")#  \n5. How many leaves am I entitled to?  \n6. How many casual leaves do I have?  \n7. and earned leaves?") 
    # query = gpt_complete.create_query("input_query: what are the peak hours at terminal 1?\n\nold_queries:1. where can i charge my EV in terminal 1?\n2. i will be dropping off my friend, are there parking charges?\n3.i want my car washed at airport is that possible?")
    message = gpt_complete.create_message(gpt_complete.prompt_msg, gpt_complete.examples, query)  
    print(gpt_complete.llm(message))(["choices"][0]["message"]["content"])  
